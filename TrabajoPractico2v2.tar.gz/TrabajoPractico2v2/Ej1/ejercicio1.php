<html>
<head>
<title>Ejercicio 1</title>
</head>
<body>
<h2>Formulario</h2>
<form action="/TrabajoPractico2/Ej1/ejercicio1b.php" method="GET">
<label for="nombre">Nombre: </label>
<input type="text" id="nombre" name="nombre"><br>
<label for="edad">Edad: </label>
<input type="text" id="edad" name="edad"><br>
<input type="submit" value="Enviar datos">
</form>
</body>
</html>
