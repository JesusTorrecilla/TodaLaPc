<html>
<head>
<title>Ejercicio 11</title>
</head>
<body>
<form action="ejercicio11b.php" method="GET"
<label for="texto1">Ingrese el primer valor numerico: </label>
<input type="text" id="texto1" name="texto1"><br>
<label for="texto2">Ingrese el segundo valor numerico: </label>
<input type="text" id="texto2" name="texto2"><br>
<input type="submit" value="Enviar Datos">
</form>
</body>
</html>
