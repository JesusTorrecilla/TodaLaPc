<html>
<head>
<title>Ejercicio 2</title>
</head>
<body>
<h2>Formulario</h2>
<form action="/TrabajoPractico2/Ej2/ejercicio2b.php" method="POST">
<label for="nombre">Nombre: </label>
<input type="text" id="nombre" name="nombre" value="Alberto"><br>
<label for="edad">Edad: </label>
<input type="text" id="edad" name="edad" value="30"><br>
<input type="submit" value="Enviar datos">
</form>
</body>
</html>

