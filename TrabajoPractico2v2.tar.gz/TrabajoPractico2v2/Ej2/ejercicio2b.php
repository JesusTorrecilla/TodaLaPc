<html>
<head>
<title>Recepcion</title>
</head>
<body>
<h2>Datos: </h2>
<?php
print_r($_POST);
?>
</body>
</html>
~           
