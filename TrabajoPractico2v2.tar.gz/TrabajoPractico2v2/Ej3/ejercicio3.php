<html>
<head>
<title>Ejercicio 3</title>
</head>
<body>
<form action="/TrabajoPractico2/Ej3/ejercicio3b.php" method="GET">
<label for="texto1">Texto1: </label>
<input type="text" id="texto1" name="texto1"><br>
<label for="texto2">Texto2: </label>
<input type="text" id="texto2" name="texto2"><br>
<label for="oculto">Oculto: </label>
<input type="hidden" id="oculto" name="oculto"><br>
<label for="clave">Clave: </label>
<input type="password" id="clave" name="clave"><br>
<label for="check1">Check1: </label>
<input type="checkbox" id="check1" name="check1"><br>
<label for="check2">Check2: </label>
<input type="checkbox" id="check2" name="check2"><br>
<label for="check3">Check3: </label>
<input type="checkbox" id="check3" name="check3"><br>
<label for="grupo1">Grupo1: </label>
<input type="radio" id="grupo1" name="grupo1" value="El Primero">
<input type="radio" id="grupo1" name="grupo1" value="El Segundo">
<input type="radio" id="grupo1" name="grupo1" value="El Tercero"><br>
<label for="grupo2">Grupo2: </label>
<input type="radio" id="grupo2" name="grupo2" value="El Primero">
<input type="radio" id="grupo2" name="grupo2" value="El Segundo">
<input type="radio" id="grupo2" name="grupo2" value="El Tercero"><br>
<label for="lista">Lista: </label>
<select name="lista">
<option>A</option>
<option>B</option>
<option>C</option>
<option>D</option>
</select><br>
<input type="submit" value="Enviar">
</form>
</body>
</html>
