<html>
<head>
<title>Ejercicio 4</title>
</head>
<body>
<a href="/TrabajoPractico2/Ej4/ejercicio4b.php">Opcion 1</a><br>
<a href="/TrabajoPractico2/Ej4/ejercicio4b.php?dato=1">Opcion 2</a><br>
<a href="/TrabajoPractico2/Ej4/ejercicio4b.php?dato=1&dato2=2&dato3=3">Opcion 3</a>
</body>
</html>
