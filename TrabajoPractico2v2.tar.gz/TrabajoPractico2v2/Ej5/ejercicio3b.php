<html>
<head>
<title>Recepcion</title>
</head>
<body>
<h2>Datos: </h2>
<?php
echo "Textbox 1: {$_GET['texto1']} <br>";
echo "Textbox 2: {$_GET['texto2']} <br>";
echo "Hidden: {$_GET['oculto']} <br>";
echo "Password: {$_GET['clave']} <br>";
echo "Checkbox 1: {$_GET['check1']} <br>";
echo "Checkbox 2: {$_GET['check2']} <br>";
echo "Checkbox 3: {$_GET['check3']} <br>";
echo "Radio grupo 1: {$_GET['grupo1']} <br>";
echo "Radio grupo 2: {$_GET['grupo2']} <br>";
echo "Lista desplegable: {$_GET['lista']} <br>"; 
?>
</body>
</html>
