<html>
<head>
<title>Recepcion</title>
</head>
<body>
<h2>Datos: </h2>
<?php
echo "Textbox 1: {$_GET['texto1']} <br>";
echo "Textbox 2: {$_GET['texto2']} <br>";
echo "Checkbox 1: {$_GET['check1']} <br>";
echo "Checkbox 2: {$_GET['check2']} <br>";
echo "Lista desplegable: {$_GET['lista']} <br>";
?>
</body>
</html>
~        

