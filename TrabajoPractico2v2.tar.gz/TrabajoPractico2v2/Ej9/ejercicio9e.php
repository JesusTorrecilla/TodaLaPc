<html>
<head>
<title>Ejercicio 9d</title>
</head>
<body>
<?php
echo 'Dato 1: ' . $_GET['dato1'] . '<br>';
echo 'Dato 2: ' . $_GET['dato2'] . '<br>';
echo 'Dato 3: ' . $_GET['dato3'] . '<br>';
echo 'Dato 4: ' . $_GET['dato4'] . '<br>';
echo 'Dato 5: ' . $_GET['dato5'] . '<br>';
echo 'Dato 6: ' . $_GET['dato6'] . '<br>';
echo 'Dato 7: ' . $_GET['dato7'] . '<br>';
echo 'Dato 8: ' . $_GET['dato8'] . '<br>';
echo 'Dato 9: ' . $_GET['dato9'] . '<br>';
?>  
</body>
</html>
