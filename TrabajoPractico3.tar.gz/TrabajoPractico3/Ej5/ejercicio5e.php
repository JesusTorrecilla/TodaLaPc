<?php
session_start();
?>
<html>
<body>
<?php
echo $_SESSION["dato1"];
echo $_SESSION["dato2"];
echo $_SESSION["dato3"];
echo $_SESSION["dato4"];
echo $_SESSION["dato5"];
echo $_SESSION["dato6"];
echo $_SESSION["dato7"];
echo $_SESSION["dato8"];
echo $_SESSION["dato9"];
?>
</body>
</html>
