<html>
<head>
<title>Ejercicio 3</title>
</head>
<body>
<form action="ejercicio3b.php" method="POST" >
<label for="nombre">Nombre: </label>               
<input type="text" name="nombre"><br>
<label for="apellido">Apellido: </label>               
<input type="text" name="apellido"><br>
<label for="documento">Documento: </label>               
<input type="text" name="documento"><br>
<label for="edad">Edad: </label>               
<input type="text" name="edad"><br>
<input type="submit" name="Enviar datos"  /> 
</form>
</body>
</html>
