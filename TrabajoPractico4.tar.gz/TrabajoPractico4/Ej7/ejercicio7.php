<html>
<head>
<title>Ejercicio 7</title>
</head>
<body>
<form action="ejercicio7b.php" method="POST" >
<label for="usuario">Usuario: </label>               
<input type="text" name="usuario"><br>
<label for="password">Password: </label>              
<input type="password" name="password"><br>
<input type="submit" name="Enviar datos"  /> 
</form>
</body>
</html
